# src/task_1_ingestion.py
import spacy
import pdfplumber
import json
import os
from langchain_text_splitters import RecursiveCharacterTextSplitter # Use the new import

# --- Configuration ---
PDF_DATA_DIR = "data/pdfs/"
OUTPUT_FILE = "results/classical_output.json"
SPACY_MODEL = "en_core_web_sm"

# --- Load NLP Model ---
# This can take a moment the first time
print(f"Loading spaCy model: {SPACY_MODEL}...")
try:
    nlp = spacy.load(SPACY_MODEL)
except IOError:
    print(f"Spacy model '{SPACY_MODEL}' not found. Please run:")
    print(f"python -m spacy download {SPACY_MODEL}")
    exit(1)
print("Spacy model loaded.")


def process_pdf(file_path):
    """
    Reads a single PDF, extracts text, and returns the full text.
    """
    print(f"Processing PDF: {os.path.basename(file_path)}...")
    full_text = ""
    with pdfplumber.open(file_path) as pdf:
        for i, page in enumerate(pdf.pages):
            page_text = page.extract_text()
            if page_text:
                # Add a reference to the page number for citation
                full_text += f"\n--- START PAGE {i+1} ---\n"
                full_text += page_text
                full_text += f"\n--- END PAGE {i+1} ---\n"
    return full_text, os.path.basename(file_path)

def chunk_text(full_text, file_name):
    """
    Splits the full text into semantic chunks with metadata.
    """
    # LangChain's splitter is good at keeping paragraphs/sentences together.
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len,
        add_start_index=True, # Helps identify chunk location
    )
    
    # We create documents with metadata (the source file)
    # This is crucial for citations later.
    chunks = text_splitter.create_documents(
        [full_text], 
        metadatas=[{"source_file": file_name}]
    )
    
    print(f"Split {file_name} into {len(chunks)} chunks.")
    return chunks

def process_chunks_with_spacy(chunks):
    """
    Runs spaCy's NLP pipeline on each chunk to extract detailed features.
    """
    processed_data = []
    
    print(f"Running NLP analysis on {len(chunks)} chunks...")
    for i, chunk in enumerate(chunks):
        if (i + 1) % 10 == 0:
            print(f"  ...analyzing chunk {i+1}/{len(chunks)}")
            
        doc = nlp(chunk.page_content)
        
        chunk_data = {
            "chunk_id": f"{chunk.metadata['source_file']}-chunk-{i}",
            "source_file": chunk.metadata['source_file'],
            "start_index": chunk.metadata['start_index'],
            "raw_text": chunk.page_content,
            "tokens": [],
            "lemmas": [],
            "pos_tags": [],
            "named_entities": []
        }
        
        # Extract linguistic features
        for token in doc:
            if not token.is_stop and not token.is_punct:
                chunk_data["tokens"].append(token.text)
                chunk_data["lemmas"].append(token.lemma_)
                chunk_data["pos_tags"].append(token.pos_)
        
        # Extract named entities
        for ent in doc.ents:
            chunk_data["named_entities"].append({
                "text": ent.text,
                "label": ent.label_
            })
            
        processed_data.append(chunk_data)
        
    return processed_data

def main():
    """
    Orchestrator function for Task 1.
    """
    # Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    os.makedirs(PDF_DATA_DIR, exist_ok=True) # Also create data dir
    
    pdf_files = [f for f in os.listdir(PDF_DATA_DIR) if f.endswith(".pdf")]
    
    if not pdf_files:
        print(f"!!! No PDF files found in {PDF_DATA_DIR}. !!!")
        print("Please add at least one .pdf file to that folder and run again.")
        return

    print(f"Found {len(pdf_files)} PDFs to process.")
    
    all_processed_data = []

    for pdf_file in pdf_files:
        file_path = os.path.join(PDF_DATA_DIR, pdf_file)
        
        # 1. Parse PDF
        full_text, file_name = process_pdf(file_path)
        
        # 2. Chunk semantically
        chunks = chunk_text(full_text, file_name)
        
        # 3. Perform NLP (Tokenize, POS, Lemma, NER)
        chunk_data = process_chunks_with_spacy(chunks)
        
        all_processed_data.extend(chunk_data)

    # 4. Save outputs
    print(f"\nSaving all {len(all_processed_data)} processed chunks to {OUTPUT_FILE}...")
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(all_processed_data, f, indent=2, ensure_ascii=False)
        
    print("\n--- Task 1 Complete ---")
    print(f"Output saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()