# src/agents/task_7_autotune.py

import os
import sys
import json
import time
from dotenv import load_dotenv
from langchain_core.embeddings import Embeddings
from sentence_transformers import SentenceTransformer
from langchain.embeddings import HuggingFaceEmbeddings
from typing import List

# --- Add 'src/agents' to path for local imports ---
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)

# --- Import from our previous tasks ---
from retriever_agent import (
    load_documents_from_json, 
    hybrid_search,
    PINECONE_INDEX_NAME,
    DATA_FILE
)
from task_6_verify_guardrails import (
    load_models as load_verifier_models,
    check_factuality_nli,
    check_semantic_alignment  # <-- NEW IMPORT
)
from task_5_debate import (
    load_llm as load_generator_llm,
    run_agent_summarizer
)

# --- Imports for this task ---
from langchain_pinecone import PineconeVectorStore
from langchain_community.retrievers import BM25Retriever
from pinecone import Pinecone

# --- Configuration ---
TUNING_LOG_FILE = "results/tuning_log.json"
TEST_QUERY = "What are the main risks identified for the global economy?"

# --- Parameters to Test ---
# We will just test alpha for this plot, keeping k constant
ALPHA_VALUES_TO_TEST = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
K_CONSTANT = 3 # Use a fixed k for a clean alpha plot

def main():
    print("--- Starting Task 7: Re-running Auto-Tuning for Plot ---")
    load_dotenv()
    
    # 1. Load all models
    print("Loading all models...")
    api_key = os.getenv("PINECONE_API_KEY")
    generator_llm = load_generator_llm()
    sbert_model, nli_pipeline = load_verifier_models()
    
    # 2. Load all data
    print("Loading documents and retrievers...")
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    pc = Pinecone(api_key=api_key)
    index = pc.Index(PINECONE_INDEX_NAME)
    pinecone_store = PineconeVectorStore(index=index, embedding=embeddings)
    documents = load_documents_from_json(DATA_FILE)
    bm25_retriever = BM25Retriever.from_documents(documents)
    
    # 3. MemoryAgent: Initialize the log
    tuning_log = []
    
    print(f"\n--- Running Tuning Loop (k={K_CONSTANT}) ---")
    
    # 4. Auto-Tune Loop
    for alpha in ALPHA_VALUES_TO_TEST:
        
        start_time = time.time()
        
        print(f"Testing with: Alpha = {alpha}, K = {K_CONSTANT}")
        
        # --- Step A: Retrieve (Task 3) ---
        retrieval_results = hybrid_search(
            query=TEST_QUERY,
            pinecone_store=pinecone_store,
            bm25_retriever=bm25_retriever,
            documents=documents,
            alpha=alpha,
            k=K_CONSTANT
        )
        
        context_text = " ".join([res['doc'].page_content for res in retrieval_results])
        
        # --- Step B: Summarize (Task 5) ---
        summary_text = run_agent_summarizer(generator_llm, TEST_QUERY, context_text)
        
        # --- Step C: Verify (Task 6) - BOTH METRICS ---
        
        # 1. Factual Precision (NLI)
        nli_label, nli_score, is_factual = check_factuality_nli(
            summary_text, context_text, nli_pipeline
        )
        
        # 2. Semantic Alignment (Cosine)
        semantic_score, is_aligned = check_semantic_alignment(
            summary_text, context_text, sbert_model
        )
        
        end_time = time.time()
        latency = end_time - start_time
        
        print(f"  -> Latency: {latency:.2f}s, NLI Score: {nli_score:.4f}, Semantic Score: {semantic_score:.4f}\n")
        
        # --- Step D: Log (MemoryAgent) ---
        tuning_log.append({
            "alpha": alpha,
            "k": K_CONSTANT,
            "latency_sec": latency,
            "factual_precision": float(nli_score), # Cast from float32
            "semantic_alignment": float(semantic_score) # Cast from float32
        })

    # 5. Save the log
    os.makedirs(os.path.dirname(TUNING_LOG_FILE), exist_ok=True)
    with open(TUNING_LOG_FILE, 'w', encoding='utf-8') as f:
        json.dump(tuning_log, f, indent=2)

    print(f"--- Task 7 (Tuning) Complete ---")
    print(f"Tuning log saved to {TUNING_LOG_FILE}")

if __name__ == "__main__":
    main()