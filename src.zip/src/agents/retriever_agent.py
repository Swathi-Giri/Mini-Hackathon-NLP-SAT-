# src/agents/retriever_agent.py

import json
import os
import numpy as np
from dotenv import load_dotenv

# --- Imports ---
from langchain_pinecone import PineconeVectorStore
from langchain_community.retrievers import BM25Retriever
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
from pinecone import Pinecone

# --- Configuration ---
DATA_FILE = "results/classical_output.json"
MODEL_NAME = "all-MiniLM-L6-v2" 
PINECONE_INDEX_NAME = "multi-agent-rag"
RESULTS_FILE = "results/retrieval_ablation.json"

def load_documents_from_json(file_path):
    """Loads data and converts to LangChain Documents."""
    print(f"Loading documents from {file_path}...")
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    documents = []
    for chunk in data:
        page_label = "Unknown"
        # Parse page number from text markers if available
        if "--- START PAGE " in chunk["raw_text"]:
            try:
                page_num = chunk["raw_text"].split("--- START PAGE ")[1].split(" ---")[0]
                page_label = f"p.{page_num}"
            except:
                pass
                
        doc = Document(
            page_content=chunk["raw_text"],
            metadata={
                "source": chunk["source_file"],
                "chunk_id": chunk["chunk_id"],
                "page": page_label
            }
        )
        documents.append(doc)
    return documents

def get_bm25_scores(bm25_retriever, query, documents):
    """
    Manually extracts BM25 scores for all documents.
    """
    # 1. Preprocess the query exactly like BM25 does internally
    query_tokens = bm25_retriever.preprocess_func(query)
    
    # 2. Get raw scores for every document in the index
    raw_scores = bm25_retriever.vectorizer.get_scores(query_tokens)
    
    # 3. Normalize scores to 0-1 range for fair combination with Cosine
    # Formula: score / max_score
    max_score = max(raw_scores) if raw_scores.any() else 1.0
    if max_score == 0: max_score = 1.0 # Avoid division by zero
    normalized_scores = [s / max_score for s in raw_scores]
    
    # Map chunk_id -> normalized_score
    score_map = {}
    for i, doc in enumerate(documents):
        score_map[doc.metadata["chunk_id"]] = normalized_scores[i]
        
    return score_map

def hybrid_search(query, pinecone_store, bm25_retriever, documents, alpha=0.5, k=5):
    """
    Performs Hybrid Search using the formula:
    S_final = alpha * S_dense + (1 - alpha) * S_sparse
    """
    print(f"Running Hybrid Search (Alpha={alpha})...")
    
    # --- 1. Get Dense Scores (Pinecone) ---
    # similarity_search_with_score returns (Document, cosine_score)
    dense_results = pinecone_store.similarity_search_with_score(query, k=k*2) # Fetch more to allow for re-ranking
    
    # Map chunk_id -> dense_score
    dense_score_map = {doc.metadata["chunk_id"]: score for doc, score in dense_results}

    # --- 2. Get Sparse Scores (BM25) ---
    sparse_score_map = get_bm25_scores(bm25_retriever, query, documents)
    
    # --- 3. Combine Scores ---
    # We iterate over the dense results (our candidates) and add the sparse signal
    hybrid_results = []
    
    # Get all unique IDs from dense results to score them
    candidate_ids = list(dense_score_map.keys())
    
    for chunk_id in candidate_ids:
        s_dense = dense_score_map.get(chunk_id, 0.0)
        s_sparse = sparse_score_map.get(chunk_id, 0.0)
        
        # THE FORMULA
        s_final = (alpha * s_dense) + ((1 - alpha) * s_sparse)
        
        # Find the actual document object
        doc_obj = next((d for d in documents if d.metadata["chunk_id"] == chunk_id), None)
        
        if doc_obj:
            hybrid_results.append({
                "doc": doc_obj,
                "score": s_final,
                "score_dense": s_dense,
                "score_sparse": s_sparse
            })
            
    # --- 4. Sort by Final Score ---
    hybrid_results.sort(key=lambda x: x["score"], reverse=True)
    
    return hybrid_results[:k]

def main():
    # 1. Load Env
    load_dotenv()
    api_key = os.getenv("PINECONE_API_KEY")
    if not api_key:
        print("Error: PINECONE_API_KEY not found in .env")
        return

    # 2. Setup Data
    documents = load_documents_from_json(DATA_FILE)
    embeddings = HuggingFaceEmbeddings(model_name=MODEL_NAME)

    # 3. Setup Pinecone (Dense)
    pc = Pinecone(api_key=api_key)
    index = pc.Index(PINECONE_INDEX_NAME)
    pinecone_store = PineconeVectorStore(index=index, embedding=embeddings)
    
    # 4. Setup BM25 (Sparse)
    bm25_retriever = BM25Retriever.from_documents(documents)

    # 5. Run Query with Custom Hybrid Logic
    test_query = "What are the main risks identified for the global economy?"
    alpha_value = 0.5
    
    final_results = hybrid_search(
        query=test_query,
        pinecone_store=pinecone_store,
        bm25_retriever=bm25_retriever,
        documents=documents,
        alpha=alpha_value,
        k=5
    )

    # 6. Save Diagnostics (Task Output)
    print(f"\nTop {len(final_results)} Results for alpha={alpha_value}:")
    
    diagnostics = {
        "query": test_query,
        "alpha": alpha_value,
        "retrieved_chunks": []
    }

    for i, res in enumerate(final_results):
        doc = res["doc"]
        print(f"{i+1}. Score: {res['score']:.4f} | Dense: {res['score_dense']:.4f} | Sparse: {res['score_sparse']:.4f}")
        print(f"   File: {doc.metadata['source']} ({doc.metadata['page']})")
        
        diagnostics["retrieved_chunks"].append({
            "rank": i + 1,
            "final_score": float(res['score']),   # The requested "Score"
            "dense_score": float(res['score_dense']),
            "sparse_score": float(res['score_sparse']),
            "chunk_id": doc.metadata['chunk_id'],
            "source": doc.metadata['source'],
            "content": doc.page_content
        })

    os.makedirs(os.path.dirname(RESULTS_FILE), exist_ok=True)
    with open(RESULTS_FILE, 'w', encoding='utf-8') as f:
        json.dump(diagnostics, f, indent=2)
        
    print(f"\n--- Task 3 Complete ---")
    print(f"Retrieval diagnostics saved to {RESULTS_FILE}")

if __name__ == "__main__":
    main()