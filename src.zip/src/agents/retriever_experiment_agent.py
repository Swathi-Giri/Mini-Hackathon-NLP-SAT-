# src/agents/retriever_experiment_agent.py

import os
import sys
import json
from dotenv import load_dotenv
from sentence_transformers import CrossEncoder # New Import
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_core.embeddings import Embeddings
from sentence_transformers import SentenceTransformer
from typing import List

# --- Add 'src/agents' to path for local imports ---
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)

# --- Import from our previous tasks ---
from retriever_agent import (
    load_documents_from_json, 
    hybrid_search,
    PINECONE_INDEX_NAME,
    DATA_FILE
)
from langchain_pinecone import PineconeVectorStore
from langchain_community.retrievers import BM25Retriever
from pinecone import Pinecone

# --- Configuration ---
COMPARISON_FILE = "results/retrieval_comparison.json"
TEST_QUERY = "What are the main risks identified for the global economy?"
BASELINE_ALPHA = 0.5 # Your best alpha from Task 7
BASELINE_K = 5

# The model suggested in your README
RERANKER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"

def main():
    print("--- Starting Task 8: Advanced RAG (Cross-Encoder Reranking) ---")
    load_dotenv()
    
    # 1. Load Baseline Retrievers (from Task 3)
    print("Loading retrievers and documents...")
    api_key = os.getenv("PINECONE_API_KEY")
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L-6-v2")
    pc = Pinecone(api_key=api_key)
    index = pc.Index(PINECONE_INDEX_NAME)
    pinecone_store = PineconeVectorStore(index=index, embedding=embeddings)
    documents = load_documents_from_json(DATA_FILE)
    bm25_retriever = BM25Retriever.from_documents(documents)

    # 2. Load the Advanced Reranker Model
    print(f"Loading Reranker model ({RERANKER_MODEL})...")
    reranker = CrossEncoder(RERANKER_MODEL)

    # 3. Run the Baseline Hybrid Search
    print(f"Running Baseline Hybrid Search (Alpha={BASELINE_ALPHA}, k={BASELINE_K})...")
    baseline_results = hybrid_search(
        query=TEST_QUERY,
        pinecone_store=pinecone_store,
        bm25_retriever=bm25_retriever,
        documents=documents,
        alpha=BASELINE_ALPHA,
        k=BASELINE_K
    )

    # 4. Run the Reranking Agent
    print("Running Reranking Agent...")
    
    # Create pairs of [query, context] for the reranker
    rerank_pairs = []
    for res in baseline_results:
        rerank_pairs.append( (TEST_QUERY, res['doc'].page_content) )
    
    # Reranker.predict() gives new scores
    rerank_scores = reranker.predict(rerank_pairs)
    
    # Add the new scores back to our results
    for i, res in enumerate(baseline_results):
        res['rerank_score'] = float(rerank_scores[i])
        
    # Sort by the new score
    reranked_results = sorted(baseline_results, key=lambda x: x['rerank_score'], reverse=True)

    # 5. Compare and Save Results
    print("\n--- Comparison (Top 3) ---")
    print("\nBASELINE (Ranked by Hybrid Score):")
    baseline_top_3 = baseline_results[:3] # Original sort
    for i, res in enumerate(baseline_top_3):
        print(f" {i+1}. {res['doc'].metadata['chunk_id']} (Hybrid Score: {res['score']:.4f})")

    print("\nRERANKED (Ranked by Cross-Encoder):")
    reranked_top_3 = reranked_results[:3] # New sort
    for i, res in enumerate(reranked_top_3):
        print(f" {i+1}. {res['doc'].metadata['chunk_id']} (Rerank Score: {res['rerank_score']:.4f})")

    # 6. Save data for plotting
    comparison_data = {
        "query": TEST_QUERY,
        "baseline_top_result": {
            "chunk_id": baseline_top_3[0]['doc'].metadata['chunk_id'],
            "score": baseline_top_3[0]['score'],
            "content": baseline_top_3[0]['doc'].page_content
        },
        "reranked_top_result": {
            "chunk_id": reranked_top_3[0]['doc'].metadata['chunk_id'],
            "score": reranked_top_3[0]['rerank_score'],
            "content": reranked_top_3[0]['doc'].page_content
        }
    }
    
    os.makedirs(os.path.dirname(COMPARISON_FILE), exist_ok=True)
    with open(COMPARISON_FILE, 'w', encoding='utf-8') as f:
        json.dump(comparison_data, f, indent=2)

    print(f"\n--- Task 8 (Experiment) Complete ---")
    print(f"Comparison data saved to {COMPARISON_FILE}")

if __name__ == "__main__":
    main()