# src/agents/task_5_debate.py

import os
import sys
import json

# --- NEW PATH FIX ---
# This forces Python to look in the parent 'src' and 'src/agents' folders
# allowing 'from retriever_agent import ...' to work correctly.
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)
# --- END FIX ---

from dotenv import load_dotenv
import importlib

# Dynamically import HuggingFacePipeline from either 'langchain_huggingface' or 'langchain'
# This avoids static import resolution errors in environments where one package name is not present.
try:
    _module = importlib.import_module("langchain_huggingface")
    HuggingFacePipeline = getattr(_module, "HuggingFacePipeline")
except Exception:
    # Some installations expose HuggingFacePipeline from the main langchain package
    try:
        _module = importlib.import_module("langchain")
        HuggingFacePipeline = getattr(_module, "HuggingFacePipeline")
    except Exception as e:
        raise ImportError(
            "Could not import HuggingFacePipeline from 'langchain_huggingface' or 'langchain'. "
            "Please install the appropriate package."
        ) from e
# ... (rest of your imports)
from langchain.prompts import PromptTemplate
from langchain.schema import Document
from langchain.embeddings import HuggingFaceEmbeddings
import pinecone
from langchain.vectorstores import Pinecone as PineconeVectorStore
from langchain.retrievers import BM25Retriever
# --- Configuration ---
MODEL_ID = "google/flan-t5-large"
DATA_FILE = "results/classical_output.json"
OUTPUT_FILE = "results/final_policy_brief.txt"

def load_documents_from_json(path):
    """
    Load documents from a JSON file and return a list of langchain Document objects.
    Accepts a JSON list of items or a dict with a "documents" key. Each item should
    contain one of: "text", "page_content", or "content", and may include a "metadata" dict.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Data file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict) and "documents" in data:
        items = data["documents"]
    elif isinstance(data, list):
        items = data
    else:
        raise ValueError("Unexpected JSON format for documents file; expect a list or {'documents': [...]}")

    docs = []
    for it in items:
        if not isinstance(it, dict):
            # Skip unexpected entries
            continue
        text = it.get("text") or it.get("page_content") or it.get("content") or ""
        metadata = it.get("metadata") if isinstance(it.get("metadata"), dict) else {}
        docs.append(Document(page_content=text, metadata=metadata))

    return docs
def load_llm():
    """Loads the local Flan-T5 model."""
    print(f"Loading LLM ({MODEL_ID})...")
    llm = HuggingFacePipeline.from_model_id(
        model_id=MODEL_ID,
        task="text2text-generation",
        pipeline_kwargs={"max_new_tokens": 512, "temperature": 0.4} # Increased temp slightly for creativity
    )
    return llm
    return llm

def format_context_with_citations(results):
    """
    Formats retrieved documents into a string with citations.
    """
    context_str = ""
    for res in results:
        doc = res['doc']
        source = doc.metadata.get('source', 'unknown')
        page = doc.metadata.get('page', '?')
        content = doc.page_content.replace("\n", " ")[:400] 
        context_str += f"- {content} [src: {source}, {page}]\n\n"
    return context_str

def run_agent_summarizer(llm, query, context):
    print("\n🤖 SUMMARIZER AGENT: Synthesizing facts...")
    
    # --- NEW PROMPT ---
    # We explicitly forbid copying.
    template = """
    You are a Policy Analyst. Your job is to answer the query by summarizing the context.
    **You MUST NOT copy the context.** Write a new, original summary in your own words.
    You MUST include the citations [src: ...] where relevant.
    
    Query: {query}
    
    Context:
    {context}
    
    Original Summary (DO NOT COPY THE CONTEXT):
    """
    prompt = PromptTemplate(template=template, input_variables=["query", "context"])
    chain = prompt | llm
    return chain.invoke({"query": query, "context": context})

def run_agent_debate_pro(llm, summary):
    print("\n🤖 DEBATE AGENT A (PRO): Arguing strengths...")
    
    # --- NEW PROMPT ---
    # We ask for a new list of bullet points.
    template = """
    You are a Policy Advocate. Read the summary and list 3 key STRENGTHS or positive points.
    **DO NOT repeat the summary.** Write a new list of bullet points.
    
    Summary: {summary}
    
    Key Strengths (as bullet points):
    """
    prompt = PromptTemplate(template=template, input_variables=["summary"])
    chain = prompt | llm
    return chain.invoke({"summary": summary})

def run_agent_debate_con(llm, summary):
    print("\n🤖 DEBATE AGENT B (CON): Arguing risks...")
    
    # --- NEW PROMPT ---
    # We ask for a new list of bullet points.
    template = """
    You are a Policy Critic. Read the summary and list 3 key RISKS or critiques.
    **DO NOT repeat the summary.** Write a new list of bullet points.
    
    Summary: {summary}
    
    Key Risks/Critiques (as bullet points):
    """
    prompt = PromptTemplate(template=template, input_variables=["summary"])
    chain = prompt | llm
    return chain.invoke({"summary": summary})

def run_agent_consensus(llm, summary, pro, con):
    print("\n🤖 CONSENSUS AGENT: Combining into final brief...")
    # Combine the summary, strengths, and risks into one balanced final paragraph.
    template = """
    You are a Lead Editor. Combine the summary, strengths, and risks into a final, balanced analysis.
    **DO NOT copy the inputs.** Write a new, concluding paragraph in your own words.
    
    Summary: {summary}
    Strengths: {pro}
    Risks: {con}
    
    Final Consensus Paragraph:
    """
    prompt = PromptTemplate(template=template, input_variables=["summary", "pro", "con"])
    chain = prompt | llm
    return chain.invoke({"summary": summary, "pro": pro, "con": con})

def hybrid_search(query, pinecone_store, bm25_retriever, documents, alpha=0.5, k=3):
    """
    A simple hybrid search that prefers semantic (pinecone) results when available,
    falling back to BM25 results and merging them to up to k documents.
    Returns a list of dicts like [{'doc': Document, ...}, ...] to match format_context_with_citations.
    """
    sem_docs = []
    bm25_docs = []
    # semantic search via Pinecone vector store if available
    if pinecone_store:
        try:
            sem_docs = pinecone_store.similarity_search(query, k=k)
        except Exception:
            sem_docs = []
    # BM25 retrieval
    try:
        bm25_docs = bm25_retriever.get_relevant_documents(query)[:k]
    except Exception:
        bm25_docs = []

    merged = []
    seen_texts = set()
    for d in (sem_docs + bm25_docs):
        text = getattr(d, "page_content", None) or getattr(d, "text", None) or ""
        if text in seen_texts:
            continue
        seen_texts.add(text)
        merged.append(d)
        if len(merged) >= k:
            break

    # Fallback: if nothing found, return the top-k documents from the provided documents list
    if not merged and documents:
        merged = documents[:k]

    return [{"doc": d} for d in merged]

def main():
    load_dotenv()
    
    # 1. Setup Resources
    llm = load_llm()
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    # Initialize Pinecone client and create an index handle (only if API key is available)
    api_key = os.getenv("PINECONE_API_KEY")
    PINECONE_INDEX_NAME = os.getenv("PINECONE_INDEX_NAME", "default-index")
    PINECONE_ENV = os.getenv("PINECONE_ENV")
    pinecone_store = None
    if api_key:
        if PINECONE_ENV:
            pinecone.init(api_key=api_key, environment=PINECONE_ENV)
        else:
            pinecone.init(api_key=api_key)
        index = pinecone.Index(PINECONE_INDEX_NAME)
        pinecone_store = PineconeVectorStore(index=index, embedding=embeddings)
    else:
        print("Warning: PINECONE_API_KEY not set; continuing without Pinecone vector store.")
    
    documents = load_documents_from_json(DATA_FILE)
    bm25_retriever = BM25Retriever.from_documents(documents)

    # 2. Define Policy Question
    query = "What are the main risks identified for the global economy?"
    print(f"--- Starting Debate Pipeline for: '{query}' ---")

    # 3. RETRIEVAL
    retrieval_results = hybrid_search(
        query, pinecone_store, bm25_retriever, documents, alpha=0.5, k=3
    )
    formatted_context = format_context_with_citations(retrieval_results)

    # 4. SUMMARIZATION
    summary_text = run_agent_summarizer(llm, query, formatted_context)
    print(f"> Summary generated ({len(summary_text)} chars)")

    # 5. DEBATE ROUND
    pro_argument = run_agent_debate_pro(llm, summary_text)
    con_argument = run_agent_debate_con(llm, summary_text)
    print("> Debate arguments generated.")

    # 6. CONSENSUS
    final_brief = run_agent_consensus(llm, summary_text, pro_argument, con_argument)

    # 7. Save Output
    output_content = f"""
    === FINAL POLICY BRIEF ===
    Query: {query}
    
    --- EXECUTIVE SUMMARY ---
    {summary_text.strip()}
    
    --- DEBATE ANALYSIS ---
    [+] STRENGTHS (Agent A):
    {pro_argument.strip()}
    
    [-] RISKS (Agent B):
    {con_argument.strip()}
    
    --- CONSENSUS ---
    {final_brief.strip()}
    """
    
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(output_content)

    print(f"\n--- Task 5 Complete ---")
    print(f"Final Brief saved to: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()