# src/agents/task_7_visualize.py

import json
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# --- Configuration ---
LOG_FILE = "results/tuning_log.json"
PLOT_DIR = "results/plots/"
OUTPUT_PLOT_FILE = os.path.join(PLOT_DIR, "rag_performance_vs_alpha.png")

def main():
    print(f"--- Task 7 (Visualizer): Loading log from {LOG_FILE} ---")
    
    # 1. Load log file
    try:
        df = pd.read_json(LOG_FILE)
    except FileNotFoundError:
        print(f"Error: {LOG_FILE} not found.")
        print("Please run 'task_7_autotune.py' first.")
        return
    except Exception as e:
        print(f"Error loading JSON: {e}")
        return

    if df.empty:
        print("Log file is empty. No data to plot.")
        return

    # Ensure plot directory exists
    os.makedirs(PLOT_DIR, exist_ok=True)
    
    # 2. Prepare data for plotting
    # We group by 'alpha' and take the average score, just in case
    # you run multiple k values in the future.
    df_plot = df.groupby('alpha').mean().reset_index()
    
    # Melt the DataFrame to long-form, which is what seaborn prefers
    df_melted = df_plot.melt(
        id_vars=['alpha'], 
        value_vars=['factual_precision', 'semantic_alignment', 'latency_sec'],
        var_name='Metric', 
        value_name='Score'
    )
    
    print("Plotting data...")
    
    # 3. Create the Plot
    plt.figure(figsize=(14, 8))
    sns.set_theme(style="darkgrid", rc={"grid.linestyle": "--"})
    
    # Use seaborn's lineplot
    line_plot = sns.lineplot(
        data=df_melted,
        x='alpha',
        y='Score',
        hue='Metric',          # This creates the 3 different colored lines
        style='Metric',        # This gives each line a different marker
        markers=True,
        markersize=10,
        linewidth=2.5
    )
    
    # 4. Customize the plot to match the example
    plt.title("RAG Pipeline Performance vs. Hybrid Search Alpha", fontsize=16)
    plt.xlabel("Alpha (Weight for Dense Search)", fontsize=12)
    plt.ylabel("") # Y-axis label is less useful when metrics are different
    
    # Fix legend titles
    handles, labels = line_plot.get_legend_handles_labels()
    new_labels = [
        'Factual Precision', 
        'Semantic Alignment', 
        'Latency (sec)'
    ]
    plt.legend(handles=handles, labels=new_labels, fontsize=12)
    
    plt.xticks(df_plot['alpha'].unique()) # Ensure all alpha values are on the x-axis
    plt.tight_layout()

    # 5. Save the plot
    plt.savefig(OUTPUT_PLOT_FILE)

    print(f"\n--- Task 7 (Visualizer) Complete ---")
    print(f"Performance plot saved to {OUTPUT_PLOT_FILE}")

if __name__ == "__main__":
    main()