# src/agents/planner_agent.py

import json
import os
import re
from langdetect import detect, DetectorFactory
from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM

# --- Configuration ---
MODEL_ID = "google/flan-t5-large" 
OUTPUT_FILE = "results/plan.json"

# Fix seed for consistent language detection
DetectorFactory.seed = 0

def detect_query_language(query):
    """Detects query language (EN/DE)."""
    try:
        lang = detect(query)
        print(f"Detected Language: {lang.upper()}")
        return lang
    except Exception as e:
        print(f"Language detection warning: {e}")
        return "en"

def load_planning_llm():
    """Loads the local LLM using Hugging Face transformers pipeline."""
    print(f"Loading Planner Agent Model ({MODEL_ID})...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_ID)
    gen = pipeline(
        "text2text-generation",
        model=model,
        tokenizer=tokenizer,
        max_new_tokens=256,
        do_sample=True,
        temperature=0.3
    )
    return gen
def clean_and_parse_list(raw_text, original_query):
    """
    Robustly extracts the list.
    """
    print(f"Raw Model Output: {raw_text}") # Debug print
    
    # 1. Attempt JSON parsing directly
    try:
        # Look for brackets
        start = raw_text.find('[')
        end = raw_text.rfind(']') + 1
        if start != -1 and end != -1:
            json_str = raw_text[start:end]
            return json.loads(json_str)
    except Exception:
        pass

    # 2. Fallback: Split by specific delimiters often used by T5
    # T5 often outputs: "Query 1, Query 2, Query 3" or "1. Query 1 2. Query 2"
    delimiters = [",", "\n", ";"]
    for d in delimiters:
        if d in raw_text:
            parts = raw_text.split(d)
            # Clean up parts
            cleaned = [p.strip().strip('"').strip("'").strip("[]") for p in parts if len(p) > 5]
            # Filter out "Sub-query" if it hallucinated it again
            cleaned = [c for c in cleaned if "Sub-query" not in c]
            if len(cleaned) >= 2:
                return cleaned

def decompose_query(llm, query):
    """
    Decomposes complex policy questions using a 'Few-Shot' prompt.
    """
    template = (
        "You are a helpful research assistant. Break the user's complex question into 3 separate, simple search questions.\n\n"
        'Example Input: "Compare the environmental impact of electric cars vs gas cars."\n'
        'Example Output: ["What is the environmental impact of electric cars?", "What is the environmental impact of gas cars?", "Comparison of electric vs gas car emissions"]\n\n'
        "User Input: \"{question}\"\n"
        "Output:\n"
    )
    prompt_text = template.format(question=query)
    print(f"Decomposing query: '{query}'")
    outputs = llm(prompt_text)
    # transformers pipeline returns list of dicts with generated text under different keys depending on version
    if isinstance(outputs, list) and outputs:
        text = outputs[0].get("generated_text") or outputs[0].get("text") or outputs[0].get("summary_text") or str(outputs[0])
    else:
        text = str(outputs)
    return clean_and_parse_list(text, query)
def main():
    # 1. The Task Input
    complex_query = "Compare the inflation policies discussed in the OECD report against the IMF financial stability guidelines."
    
    # 2. Detect Language
    lang = detect_query_language(complex_query)
    
    # 3. Initialize Planner
    llm = load_planning_llm()
    
    # 4. Run Decomposition
    sub_queries = decompose_query(llm, complex_query)
    
    print("\n--- Plan Generated ---")
    print(f"Original: {complex_query}")
    print(f"Sub-queries: {sub_queries}")
    
    # 5. Save
    output_data = {
        "original_query": complex_query,
        "language": lang,
        "sub_queries": sub_queries,
        "planner_model": MODEL_ID
    }
    
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2)
        
    print(f"Plan saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()