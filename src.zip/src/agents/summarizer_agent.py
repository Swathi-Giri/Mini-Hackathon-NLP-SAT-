import ollama
import json

class SummarizerAgent:
    
    def __init__(self):
        """
        Initializes the SummarizerAgent and connects to the local Ollama client.
        """
        try:
            self.client = ollama.Client()
            self.client.show("mistral")
            print("Ollama client initialized for SummarizerAgent.")
        except Exception as e:
            print(f"Error initializing Ollama client for Summarizer: {e}")
            raise

    def create_context_string(self, retrieved_docs):
        """
        Converts the list of retrieved documents into a single string for the prompt.
        """
        context_str = ""
        for i, doc in enumerate(retrieved_docs):
            context_str += f"[Source {i+1}: file={doc['source_file']}, chunk={doc['doc_id']}]\n"
            context_str += f"{doc['text']}\n"
            context_str += "-----------------\n"
        return context_str

    def run(self, query, retrieved_docs):
        """
        Generates a structured, cited summary for a query given retrieved documents.
        """
        print(f"\n--- SummarizerAgent running for query: '{query}' ---")
        
        # 1. Create the context string from the documents
        context = self.create_context_string(retrieved_docs)
        
        # 2. Create a specific, system-level prompt
        # This prompt is "zero-shot" and instructs the model to follow a strict format.
        prompt = f"""
        You are an expert policy analyst. Your task is to write a structured summary
        in response to the user's query.
        
        You must follow these rules:
        1. Base your answer *ONLY* on the provided sources.
        2. Do not use any outside knowledge.
        3. You *MUST* cite your sources for every claim you make.
        4. Cite sources using the format: [Source X, file=filename.pdf]
        
        Here is the context (sources) you must use:
        {context}
        
        Here is the user's query:
        "{query}"
        
        Now, write the structured summary with citations.
        """
        
        try:
            # 3. Call the LLM
            response = self.client.chat(
                model='mistral',
                messages=[{'role': 'user', 'content': prompt}]
            )
            
            summary = response['message']['content']
            print("--- Summary Generated ---")
            print(summary)
            return summary
            
        except Exception as e:
            print(f"Error during summarization: {e}")
            return "Error: Could not generate summary."