# src/task_2_analysis.py

import json
import os
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.manifold import TSNE
from sentence_transformers import SentenceTransformer
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# --- Configuration ---
INPUT_FILE = "results/classical_output.json"
PLOT_OUTPUT_FILE = "results/embedding_map.png"
NUM_TOPICS = 10 # As requested in README

def print_top_words(model, feature_names, n_top_words):
    """Helper function to print topics"""
    print("\n--- Top Words per Topic ---")
    for topic_idx, topic in enumerate(model.components_):
        message = f"Topic #{topic_idx}: "
        message += " ".join([feature_names[i]
                            for i in topic.argsort()[:-n_top_words - 1:-1]])
        print(message)
    print("----------------------------")

def main():
    """
    Main function to run Task 2:
    1. Load data from Task 1
    2. Run LDA Topic Modeling
    3. Generate SBERT embeddings
    4. Run t-SNE and save visualization
    """
    
    # Suppress warnings
    warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")
    print("All libraries imported.")

    # --- Load and Prepare Data ---
    print(f"Loading data from {INPUT_FILE}...")
    try:
        with open(INPUT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"ERROR: Input file not found at {INPUT_FILE}")
        print("Please make sure you have successfully run Task 1 first.")
        return

    # 1. For LDA: Use lemmas
    lda_texts = [" ".join(chunk['lemmas']) for chunk in data]
    # 2. For SBERT: Use raw text
    sbert_texts = [chunk['raw_text'] for chunk in data]
    print(f"Loaded and prepared text for {len(data)} chunks.")

    # --- Part 1: Topic Modeling (LDA) ---
    print("\nStarting Task 2, Part 1: Topic Modeling (LDA)...")
    
    print("Creating TF-IDF matrix...")
    vectorizer = TfidfVectorizer(max_df=0.90, min_df=5, stop_words='english')
    tfidf_matrix = vectorizer.fit_transform(lda_texts)
    feature_names = vectorizer.get_feature_names_out()

    print(f"Running LDA to find {NUM_TOPICS} topics...")
    lda = LatentDirichletAllocation(
        n_components=NUM_TOPICS, 
        max_iter=10, 
        learning_method='online', 
        random_state=42
    )
    lda.fit(tfidf_matrix)
    print("LDA model fitting complete.")
    
    # Print the results
    print_top_words(lda, feature_names, 10)

    # --- Part 2: Generate SBERT Embeddings ---
    print("\nStarting Task 2, Part 2: Generating SBERT Embeddings...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    
    # This is the main computation! It can take a minute.
    # The model will download itself the first time.
    embeddings = model.encode(sbert_texts, show_progress_bar=True)
    print(f"Embeddings generated. Matrix shape: {embeddings.shape}")

    # --- Part 3: Run t-SNE Visualization ---
    print("\nStarting Task 2, Part 3: Running t-SNE...")
    # t-SNE is also computationally expensive.
    tsne = TSNE(
        n_components=2, 
        verbose=1, 
        perplexity=30, 
        max_iter=1000, 
        random_state=42
    )
    tsne_results = tsne.fit_transform(embeddings)
    print("t-SNE computation complete.")

    # --- Part 4: Plot and Save the Embedding Map ---
    print(f"Generating and saving plot to {PLOT_OUTPUT_FILE}...")

    # Get the dominant topic for each document to use for coloring
    topic_distributions = lda.transform(tfidf_matrix)
    dominant_topic = np.argmax(topic_distributions, axis=1)

    # Ensure the results directory exists
    os.makedirs(os.path.dirname(PLOT_OUTPUT_FILE), exist_ok=True)

    # Create the plot
    plt.figure(figsize=(16, 10))
    sns.scatterplot(
        x=tsne_results[:, 0],
        y=tsne_results[:, 1],
        hue=dominant_topic, # Color by topic!
        palette=sns.color_palette("hsv", NUM_TOPICS),
        s=50, # Dot size
        alpha=0.7, # Transparency
        legend="full"
    )
    plt.title(f't-SNE Visualization of Document Chunks (Colored by {NUM_TOPICS} LDA Topics)')
    plt.xlabel('t-SNE Component 1')
    plt.ylabel('t-SNE Component 2')
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    plt.tight_layout()

    # Save the plot to the file
    plt.savefig(PLOT_OUTPUT_FILE)

    print(f"\n--- Task 2 Complete ---")
    print(f"Embedding map saved to {PLOT_OUTPUT_FILE}")

# This makes the script runnable from the command line
if __name__ == "__main__":
    main()